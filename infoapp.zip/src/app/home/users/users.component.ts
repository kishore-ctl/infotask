import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  users: any =[];
  constructor(private commonService: CommonService) { }

  ngOnInit(): void {
    console.log('asafsd');
    this.getUserList();
  }

  getUserList() {
    this.commonService.getUserList().subscribe((response:any) => {
      if(response && response.data.length) {
        this.users = response.data;
      }
    })
  }

}
